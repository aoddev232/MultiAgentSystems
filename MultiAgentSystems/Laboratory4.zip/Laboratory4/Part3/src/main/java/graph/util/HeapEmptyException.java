package graph.util;

public class HeapEmptyException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = 2803827481117978044L;

}
