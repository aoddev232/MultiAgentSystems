package graph.core;

public class InvalidVertexException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
