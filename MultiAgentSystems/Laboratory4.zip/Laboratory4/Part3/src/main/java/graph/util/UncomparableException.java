package graph.util;

public class UncomparableException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = -145273379219449142L;

}
